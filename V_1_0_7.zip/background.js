chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // Detect if the URL has changed and it's a YouTube video
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes("youtube.com/watch")) {
        // Send a message to the popup or handle auto-resync logic
        chrome.storage.local.set({ lastVideoUrl: tab.url, needsResync: true });
    }
});